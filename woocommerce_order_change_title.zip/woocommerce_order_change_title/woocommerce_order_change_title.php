<?php
/*
	Plugin Name: Woocommerce Order Change Title
	Plugin URI: http://www.livebricks.com
	Description: Plugin for Woocommerce Change title with Order View
	Author: Bryan Yen
	Version: 1.0
	Author URI: http://www.livebricks.com
*/

// Rename order status in the bulk actions dropdown on main order list
function rename_bulk_status( $translated_text, $untranslated_text, $domain ) {
   if( $translated_text === 'Recent Request' && is_wc_endpoint_url( 'order-received' ) ) {
       $translated_text = __( 'Order','woocommerce' );
    }
    return $translated_text;
}

add_filter('gettext', 'rename_bulk_status', 20, 3);

?>